import matplotlib.pyplot as plt
import random
import sys
import numpy as np

import matplotlib
config = matplotlib.matplotlib_fname()
print('配置文件:{}'.format(config))

# plt.rcParams['font.sans-serif'].insert(0, 'Microsoft Yahei UI')

from matplotlib.font_manager import FontProperties
font = FontProperties(family='SimHei', weight='bold')
plt.rcParams['font.sans-serif'].insert(0, 'SimHei')
plt.rcParams['axes.unicode_minus'] = False

def mpl1_first():
    plt.clf()

    # x = np.arange(5)
    # y = x * x

    x = range(5)
    y = [i * i for i in x]
    plt.plot(x, y, label='$y=x^2$')
    plt.title('第一个图形', fontproperties=font)
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.grid()
    plt.show()
    # plt.savefig('fig1.pdf')
    # plt.savefig('fig1.png')

# mpl1_first()

def mpl2_line2d():
    """ fmt:  [color][marker][linestyle]
    """
    fmts = [
        'r',     # red, default
        'yo--',  # yello, circle, dashed
        'cs-.',  # cyan, square, dashed-dot
        'mv:',   # magenta, triangle, dotted
    ]
    plt.clf()
    # x = np.arange(8)
    # y = [ x + i for i in range(4)]

    x = range(8)
    y = [[item + i for item in x] for i in range(4)]

    for i in range(4):
        plt.plot(x, y[i], fmts[i], label='$y=x+{}$'.format(i))
    plt.plot([4], [4], 'o', [4,4], [0, 4], 'g-', linewidth=2)
    plt.title('Line2D格式')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.grid()
    plt.show()

# mpl2_line2d()

def mpl3_legend():
    plt.clf()
    # x = np.arange(8)
    # y = [ x + i for i in range(4)]

    x = range(8)
    y = [[item + i for item in x] for i in range(4)]

    for i in range(4):
        plt.plot(x, y[i])
    plt.title('Line2D图例')
    plt.legend(['$y=x+{}$'.format(i) for i in range(4)], loc='best')
    # plt.legend(['$y=x+{}$'.format(i) for i in range(4)], bbox_to_anchor=(0.6, 1.0), loc='lower left', ncol=2)
    plt.show()

# mpl3_legend()

def mpl4_text():
    plt.clf()
    # x = np.arange(8)
    # y = [ x + i for i in range(4)]

    x = range(8)
    y = [[item + i for item in x] for i in range(4)]
    for i in range(4):
        plt.plot(x, y[i], label='$y=x+{}$'.format(i))
    plt.text(4, 3.7, '4,4')
    plt.text(6, 2, 'matplotlib', bbox=dict(facecolor='red', alpha=0.5))
    plt.annotate('(6,4)', xy=(6, 4))
    plt.annotate('(3,3)', xy=(3, 3), xytext=(3, 1.5),
             arrowprops=dict(color='red', arrowstyle='-|>'))
    plt.title('文本支持Tex: $y=x^2$')
    plt.legend()
    plt.show()

# mpl4_text()

def mpl5_setp():
    plt.clf()
    colors = 'rgbcmykw'
    # x = np.arange(8)
    # y = [ x + i for i in range(4)]

    x = range(8)
    y = [[item + i for item in x] for i in range(4)]
    for i in range(4):
        lines = plt.plot(x, y[i])
        plt.setp(lines, label='$y=x+{}$'.format(i), color=colors[i])
    plt.title('Line2D改变属性')
    plt.legend()
    plt.show()

# mpl5_setp()

def mpl6_ticks():
    import calendar
    y = np.random.randint(0,500, size=12)

    y = [random.randint(0, 500) for i in range(12)]
    plt.plot(y,'o-')
    plt.xlabel('month')
    plt.ylabel('income (k)')
    plt.xlim(0, 12)
    plt.ylim(0, 550)

    plt.xticks(range(12), calendar.month_name[1:13], rotation=30)
    plt.yticks(range(0, 501, 50))
    plt.grid()

    plt.show()

# mpl6_ticks()

import matplotlib.ticker as ticker
def mpl7_ticks_formatter():

    def make_label(value, pos):
        return '%0.1f%%' % (100. * value)

    ax = plt.gca()
    ax.xaxis.set_major_formatter(ticker.FuncFormatter(make_label))
    ax.xaxis.set_major_locator(ticker.MultipleLocator(base=0.2))
    ax.xaxis.set_minor_locator(ticker.MultipleLocator(base=0.05))
    ax.yaxis.set_major_formatter(ticker.StrMethodFormatter('{x:1.2f}'))
    x = np.linspace(0, 1, 256)
    y1 = np.exp(-10 * x)
    y2 = np.exp(-5 * x)
    plt.plot(x, y1)
    plt.plot(x, y2, linestyle='--')
    plt.grid(which='both', linestyle='--', color='0.75')
    plt.show()

# mpl7_ticks_formatter()

def mpl8_aspect():
    plt.figure(figsize=(10, 10))
    x = np.arange(-100, 100, 1/8)
    plt.plot(x, x, label='y=x')
    plt.plot(x, 3*x, label='y=3x')
    plt.legend()
    plt.grid(which='both', linestyle='--', color='0.75')

    ax = plt.gca()
    ax.set_aspect('equal')
    plt.xlim(-110, 110)
    plt.ylim(-110, 110)

    ax.spines['right'].set_color('none')
    ax.spines['top'].set_color('none')
    ax.spines['bottom'].set_position(('data',0))
    ax.spines['left'].set_position(('data',0))

    plt.show()

# mpl8_aspect()

def mpl9_subplot():
    x0 = np.linspace(-4 * np.pi, 4 * np.pi, 512)
    y0 = np.sin(x0)
    y1 = np.cos(x0)

    x1 = np.arange(-10, 10)
    y3 = 4 * x1 + 1

    fig = plt.figure("多图", figsize=(10, 8))
    ax1 = plt.subplot(2, 2, 1)
    plt.plot(x0, y0, label='fig 1')

    ax2 = plt.subplot(2, 2, 2)
    plt.plot(x1, y3, label='fig 2')

    ax3 = plt.subplot(2, 1, 2)
    plt.plot(x0, y1, label='fig 3')
    plt.tight_layout()
    plt.show()

# mpl9_subplot()

def mpl10_subplots():
    x0 = np.linspace(-4 * np.pi, 4 * np.pi, 64)
    y0 = np.sin(x0)
    y1 = np.cos(x0)

    x1 = np.arange(-10, 10, 0.1)
    y3 = 4 * x1 + 1
    y4 = np.cbrt(x1)  # 立方根

    fig, axes = plt.subplots(2, 2, sharex='col', figsize=(10, 8))
    axes[0][0].plot(x0, y0)
    axes[1][0].plot(x0, y1)

    axes[0][1].plot(x1, y3)
    axes[1][1].plot(x1, y4)

    plt.show()
    # plt.savefig('1.pdf')

# mpl10_subplots()

import string
char_counter = {}
for ch in string.ascii_lowercase:
    char_counter[ch] = random.random()
    # char_counter[ch] = np.random.rand()
total = sum(char_counter.values())
for ch in char_counter:
    char_counter[ch] /= total

def mpl10_bar():
    # char_counter统计每个英文字母出现的频率
    fig1, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8))
    ax1.bar(list(char_counter), list(char_counter.values()))

    data = sorted(char_counter.items(), key=lambda item: (item[1],item[0]), reverse=True)
    x = [x for x, y in data[:10]]
    y = [y for x, y in data[:10]]
    c = ['r' if i % 2  else 'g' for i in range(len(x)) ]
    ax2.barh(x, y, color=c)
    plt.show()

# mpl10_bar()

def mpl11_bar2():
    # %matplotlib inline
    N = 5
    mean_scores = [[random.randint(70, 100) for j in range(3)] for i in range(N)]
    class_names = ['Class {}'.format(i) for i in range(N)]
    maths = [math for math,literature,english in mean_scores]
    literature = [literature for math,literature,english in mean_scores]
    english = [english for math,literature,english in mean_scores]

    x1 = list(range(N))
    # 宽度0.25, gap 0.25, 3 * 0.25 + 0.25 = 1
    x2 = [i + 0.25 for i in x1]
    x3 = [i + 0.5 for i in x1]

    plt.bar(x1, maths, width=0.25, label='数学')
    plt.bar(x2, literature, width=0.25, label='语文')
    plt.bar(x3, english, width=0.25, label='英语')
    xticks = [i + 0.25 for i in x1]
    plt.xticks(xticks, class_names)
    plt.ylim(0, 135)
    plt.yticks(range(0, 101, 20))
    plt.legend()
    plt.show()

# mpl11_bar2()

def mpl12_pie():
    ranks = np.random.randint(20, 41, 5)
    rank_names = list('ABCDF')

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))
    ax1.pie(ranks, labels=rank_names, rotatelabels=True,
             colors=['r', 'g', 'b', 'k', 'gold'])
    ax1.set_aspect('equal')

    labels = 'Frogs', 'Hogs', 'Dogs', 'Logs'
    sizes = [15, 30, 45, 10]
    explode = (0, 0.1, 0, 0)  # only "explode" the 2nd slice (i.e. 'Hogs')

    ax2.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%', shadow=True, startangle=90)
    ax2.axis('equal')
    plt.show()

# mpl12_pie()

from matplotlib import patches
def mpl13_scatter():
    circle = patches.Circle((0, 0), radius=1, alpha=0.2, color='k', linestyle='-')
    ax = plt.gca()
    ax.set_aspect('equal')
    ax.add_patch(circle)
    N = 5000
    x = np.random.rand(N) * 2 - 1
    y = np.random.rand(N) * 2 - 1
    not_in_circle = (x * x + y * y) > 1
    c = np.full((N,),'r')
    c[not_in_circle] = 'k'
    plt.scatter(x, y, s=2, c=c)
    plt.show()

# mpl13_scatter()


def mpl14_hist():

    mu, sigma = 0, 0.1 # mean and standard deviation
    fig, (ax1, ax2) = plt.subplots(2, 1)
    s = np.random.normal(mu, sigma, 1000)
    count, bins, patches = ax1.hist(s, 30, density=True)
    print(count, bins)
    ax1.plot(bins, 1/(sigma * np.sqrt(2 * np.pi)) *
           np.exp(-(bins - mu)**2 / (2 * sigma ** 2) ), linewidth=2, color='r')

    ax2.hist(s, 30, cumulative=True, density=True)
    plt.show()

# mpl14_hist()

if __name__ == '__main__':
    funcs = [name for name in dir() if name.startswith('mpl')]
    func_mapping = {}
    for item in funcs:
        idx, desc = item[3:].split('_', 1)
        func_mapping[int(idx)] = desc
    while True:
        for idx in sorted(func_mapping):
            print(f'{idx}:\t{func_mapping[idx]}')

        n = input('您的选择是: ')
        if not n:
            break
        try:
            n = int(n)
            if n not in func_mapping:
                continue
            eval(f'mpl{n}_{func_mapping[n]}()')
        except Exception as e:
            print(type(e), e)
